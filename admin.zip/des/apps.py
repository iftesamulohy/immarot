# -*- coding: utf-8
from django.apps import AppConfig


class DjangoDesConfig(AppConfig):
    name = 'des'
    verbose_name = 'Dynamic Email Settings'
    verbose_name_plural = verbose_name
    # default_auto_field = 'django.db.models.BigAutoField'
