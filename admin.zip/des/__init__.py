__version__ = '2.4.1'
default_app_config = 'des.apps.DjangoDesConfig'
