from django.shortcuts import render
from rest_framework_simplejwt.views import TokenObtainPairView
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework_simplejwt.tokens import AccessToken
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework import permissions
from django.contrib.auth.models import Group, Permission
from rest_framework import status
from users.permissions import IsStaff
try:
    from globalapp.ed import encode_jwt
except:
    pass
from globalapp.views import BaseViews
from users.models import Roles, Users
from users.serializers import AllUserSerializer, CustomTokenObtainPairSerializer, GropuSerializer, PermissionSerializer, RolesSerializer, UserSerializer
# Create your views here.
class CustomTokenObtainPairView(TokenObtainPairView):
    serializer_class =CustomTokenObtainPairSerializer
    def post(self, request, *args, **kwargs):
        response = super().post(request, *args, **kwargs)
        token=response.data['access']
        payload = AccessToken(token).payload
        user_id = payload.get('user_id')
        user = Users.objects.filter(id=user_id)
        serializer = AllUserSerializer(user, many=True)
        for user_data in serializer.data:
            if 'roles' in user_data:
                for role in user_data['roles']['menu']:
                    if 'permissions' in role:
                        for permission in role['permissions']:
                            permission['submenu'] = permission['codename'].split('_')[1]
                            permission['access'] = permission['codename'].split('_')[0]
        
        serializer.instance = user
        try:
            response.data["user"] = encode_jwt({"data": serializer.data})

        except:
            response.data["user"] = {"data": serializer.data}
        return response

class RoleViewSet(BaseViews):
    authentication_classes = [JWTAuthentication]
    permission_classes = [permissions.IsAuthenticated,IsStaff]
    model_name = Roles
    methods=["list", "retrieve", "create", "update", "partial_update", "destroy", "soft_delete", "change_status", "restore_soft_deleted"]
    queryset = Roles.objects.all()
    serializer_class = RolesSerializer

class GroupViewSet(BaseViews):
    authentication_classes = [JWTAuthentication]
    permission_classes = [permissions.IsAuthenticated,IsStaff]
    model_name = Group
    
    methods=["list", "retrieve", "create", "update", "partial_update", "destroy", "soft_delete", "change_status", "restore_soft_deleted"]
    serializer_class = GropuSerializer

class PermissionViewSet(BaseViews):
    authentication_classes = [JWTAuthentication]
    permission_classes = [permissions.IsAuthenticated,IsStaff]
    model_name = Permission
    
    methods=["list", "retrieve", "create", "update", "partial_update", "destroy", "soft_delete", "change_status", "restore_soft_deleted"]
    serializer_class = PermissionSerializer
    def list(self, request, *args, **kwargs):
        if "list" in self.methods:
            try:
                limit = request.GET.get('limit')
            except:
                limit = None
            if limit is None:
                # No limit parameter provided, return all data
                
                queryset = self.filter_queryset(self.get_queryset())
                # print(self.get_queryset())
                serializer = self.get_serializer(queryset, many=True)
                for data in serializer.data:
                    data['access'] = data['codename'].split('_')[0]
                    # print(data)

                token = encode_jwt({"data": serializer.data})  # Encode serialized data into JWT token
                return self.generate_response(True, status.HTTP_200_OK, "list_success", data={"token": token})
            else:
                # Pagination requested, apply pagination
                queryset = self.filter_queryset(self.get_queryset())
                page = self.paginate_queryset(queryset)
                if page is not None:
                    serializer = self.get_serializer(page, many=True)
                    for data in serializer.data:
                        data['access'] = data['codename'].split('_')[0]
                    # print(data)
                    token = encode_jwt({"data": serializer.data})  # Encode serialized data into JWT token
                    return self.get_paginated_response({"token": token})
        else:
            return self.generate_response(False, status.HTTP_405_METHOD_NOT_ALLOWED, "list_not_allowed")
        
class UserViewSet(BaseViews):
    authentication_classes = [JWTAuthentication]
    permission_classes = [permissions.IsAuthenticated,IsStaff]
    model_name = Users
    methods=["list", "retrieve", "create", "update", "partial_update", "destroy", "soft_delete", "change_status", "restore_soft_deleted"]
    serializer_class = UserSerializer