from django.contrib import admin

from cms.models import FAQ, Banner, BannerItem, Blog, Page, Testimonial

# Register your models here.
admin.site.register(Page)
admin.site.register(FAQ)
admin.site.register(Testimonial)
admin.site.register(Blog)
admin.site.register(Banner)
admin.site.register(BannerItem)