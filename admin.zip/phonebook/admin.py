from django.contrib import admin

from phonebook.models import Phone

# Register your models here.
admin.site.register(Phone)