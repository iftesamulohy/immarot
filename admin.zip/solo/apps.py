from django.apps import AppConfig


class SoloAppConfig(AppConfig):
    name = 'solo'
    verbose_name = "solo"
