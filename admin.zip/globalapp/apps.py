from django.apps import AppConfig


class GlobalappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'globalapp'
    
